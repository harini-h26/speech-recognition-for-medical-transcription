import speech_recognition as sr

# Initialize recognizer class (for recognizing speech)
recognizer = sr.Recognizer()

# Function to recognize speech from microphone
def recognize_speech_from_mic():
    # Use the microphone as the audio source
    with sr.Microphone() as source:
        print("Adjusting for ambient noise... Please wait a moment.")
        recognizer.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        
        print("Listening... Please speak now.")
        # Listen to the first phrase
        audio = recognizer.listen(source)
        
        # Try to recognize the speech using Google's speech recognition API
        try:
            print("Recognizing... Please wait.")
            text = recognizer.recognize_google(audio)  # Uses Google's Speech Recognition API
            print(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            # If speech is unintelligible, print an error
            print("Sorry, I could not understand the audio.")
            return None
        except sr.RequestError as e:
            # If the API request failed
            print(f"Could not request results from Google Speech Recognition service; {e}")
            return None

# Main function to call the speech recognition function
if __name__ == "__main__":
    print("Starting the speech recognition process...")
    recognized_text = recognize_speech_from_mic()
    if recognized_text:
        print("Recognized Speech:", recognized_text)
